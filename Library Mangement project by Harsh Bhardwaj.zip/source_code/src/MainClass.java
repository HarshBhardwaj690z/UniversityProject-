/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Administrator
 */
public class MainClass 
{
    public static void main(String[] args){

    }
    //change your mysql database connection here
    public String StrUrl="jdbc:mysql://localhost/libdatabase"; //db name
    public String StrUid="root";
    public String StrPwd= "user"; //password
    
    public static String StrUser;
            

}
