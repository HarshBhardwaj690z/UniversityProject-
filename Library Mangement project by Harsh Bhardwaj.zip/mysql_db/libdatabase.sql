CREATE DATABASE `libdatabase`;

USE libdatabase;


DROP TABLE IF EXISTS `lib_book_category`;

CREATE TABLE `lib_book_category` (
  `book_category` varchar(100) NOT NULL,
  PRIMARY KEY  (`book_category`)
) ;


INSERT INTO `lib_book_category` (`book_category`) VALUES 
 ('Database'),
 ('Programming'),
 ('Web');


DROP TABLE IF EXISTS `lib_book_master`;

CREATE TABLE `lib_book_master` (
  `book_id` int(10) unsigned NOT NULL auto_increment,
  `book_title` varchar(100) default NULL,
  `book_author` varchar(100) NOT NULL,
  `book_publisher` varchar(100) NOT NULL,
  `book_publish_year` varchar(45) NOT NULL,
  `book_category` varchar(100) NOT NULL,
  `book_keyword` varchar(250) NOT NULL,
  `book_status` varchar(45) default NULL,
  PRIMARY KEY  (`book_id`)
);


INSERT INTO `lib_book_master` (`book_id`,`book_title`,`book_author`,`book_publisher`,`book_publish_year`,`book_category`,`book_keyword`,`book_status`) VALUES 
 (1,'Mastering VB6','Mr. J. K','MSN','1999','Programming','VB6, Programming','Issued'),
 (2,'Oracle Handbook','Mr. Oracle','Oracle Press','2010','Database','Oracle, Database','Available'),
 (4,'JAVA 123','Atanu','P2P','2000','Programming','Java','Available'),
 (5,'Easy HTML','Mr. Jarry','P2P','2009','Web','HTML, Web','Available'),
 (6,'JAVA handbook','Sun','Sun','2010','Programming','Java, Programming','Available'),
 (7,'MS Office Easy','Microsoft','MSN','2010','Programming','MS Office','Available');


DROP TABLE IF EXISTS `lib_member_master`;

CREATE TABLE `lib_member_master` (
  `mem_id` int(11) NOT NULL auto_increment,
  `mem_name` varchar(100) default NULL,
  `mem_address` varchar(250) default NULL,
  `mem_email_id` varchar(100) default NULL,
  `mem_mobile_no` varchar(20) default NULL,
  `mem_active` varchar(1) default NULL,
  PRIMARY KEY  (`mem_id`)
) ;


INSERT INTO `lib_member_master` (`mem_id`,`mem_name`,`mem_address`,`mem_email_id`,`mem_mobile_no`,`mem_active`) VALUES 
 (1,'Aditya','Mumai','aditya@programmer2programer.et','996774212','Y'),
 (2,'Atanu Maity','Mumbai, India','ajprofessioals@gmail.com','9999999999','Y'),
 (3,'Sunil Sharma','New Delhi','sunil.sharma@gmail.com','9999632333','Y');


DROP TABLE IF EXISTS `lib_transaction`;
CREATE TABLE `lib_transaction` (
  `trn_id` int(10) unsigned NOT NULL auto_increment,
  `trn_mem_id` int(10) unsigned NOT NULL,
  `trn_book_id` int(10) unsigned NOT NULL,
  `trn_issue_dt` date NOT NULL,
  `trn_receive_dt` date default NULL,
  PRIMARY KEY  (`trn_id`)
) ;

INSERT INTO `lib_transaction` (`trn_id`,`trn_mem_id`,`trn_book_id`,`trn_issue_dt`,`trn_receive_dt`) VALUES 
 (1,1,1,'2012-01-01','2012-01-01'),
 (2,1,2,'2012-09-08','2012-09-09'),
 (3,2,1,'2012-09-08','2012-09-09'),
 (4,1,1,'2012-09-09',NULL),
 (5,3,6,'2012-09-09','2012-09-09'),
 (6,2,7,'2012-09-09','2012-09-09');


DROP TABLE IF EXISTS `lib_user`;
CREATE TABLE `lib_user` (
  `user_name` varchar(45) NOT NULL,
  `user_password` varchar(45) NOT NULL,
  `user_type` varchar(45) NOT NULL,
  `user_active` varchar(45) NOT NULL,
  PRIMARY KEY  (`user_name`)
) ;


INSERT INTO `lib_user` (`user_name`,`user_password`,`user_type`,`user_active`) VALUES 
 ('Harsh','@123','Admin','YES'),
 ('Raja','123','User','YES'),
 ('Noor','1001','Admin','NO'),
 ('Vardhan','var123','User','YES');